import cv2
from pyzbar.pyzbar import decode
from openpyxl import load_workbook, Workbook
import logging
from datetime import datetime
import os
import time

# Get the current script directory
script_dir = os.path.dirname(os.path.realpath(__file__))

# Setup logging
logging.basicConfig(level=logging.INFO,
                    format='%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')
logger = logging.getLogger()
fhandler = logging.FileHandler(filename=os.path.join(script_dir, 'qr_scanner.log'), mode='a')
formatter = logging.Formatter('%(asctime)s %(message)s', datefmt='%m/%d/%Y %I:%M:%S %p')
fhandler.setFormatter(formatter)
logger.addHandler(fhandler)
logger.addHandler(logging.StreamHandler())  # log to console

try:
    # Load or create a new Excel workbook
    try:
        book = load_workbook(os.path.join(script_dir, 'qr_codes.xlsx'))
        sheet = book.active
    except FileNotFoundError:
        book = Workbook()
        sheet = book.active
        sheet['A1'] = 'QR Code Data'
        book.save(os.path.join(script_dir, 'qr_codes.xlsx'))
        logger.info('Created new Excel file qr_codes.xlsx')

    # Access the webcam
    cap = cv2.VideoCapture(0)

    last_qr_data = None  # Variable to store the last scanned QR code data

    while True:
        # Capture frame-by-frame
        ret, frame = cap.read()

        # Decoding the QR codes
        for qr_code in decode(frame):
            data = qr_code.data.decode('utf-8')

            # Check if the QR code data already exists in the Excel
            if data in [cell.value for cell in sheet['A']]:
                if data != last_qr_data:
                    logger.warning('Duplicate QR code detected: {}. Not added to Excel.'.format(data))
                    last_qr_data = data
            else:
                sheet.append([data])
                book.save(os.path.join(script_dir, 'qr_codes.xlsx'))
                logger.info('Detected QR code: {}'.format(data))
                logger.info('Saved QR code to Excel file')
                logger.info('Ready for the next QR code')
                last_qr_data = data
                time.sleep(1)  # pause for a second after a successful scan

        # Display the resulting frame
        cv2.imshow('QR code scanner', frame)

        # Break the loop if 'q' is pressed
        if cv2.waitKey(1) & 0xFF == ord('q'):
            book.save(os.path.join(script_dir, 'qr_codes.xlsx'))
            logger.info('Finished session, saved and closed Excel file')
            break

except Exception as e:
    logger.error(f"An error occurred: {e}")

finally:
    # When everything done, release the capture and destroy the windows
    if 'cap' in locals():  # check if 'cap' exists
        cap.release()
    cv2.destroyAllWindows()
