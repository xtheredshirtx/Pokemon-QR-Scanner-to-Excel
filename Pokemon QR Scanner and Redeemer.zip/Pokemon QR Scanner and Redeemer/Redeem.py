from openpyxl import load_workbook
from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.chrome.service import Service
from selenium.webdriver.common.keys import Keys
from selenium.webdriver.chrome.options import Options
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from webdriver_manager.chrome import ChromeDriverManager
import time
import pandas as pd
import os
import configparser

# Read the login details from the text document
config = configparser.ConfigParser()
config.read('login_details.txt')

username = config.get('Login', 'username')
password = config.get('Login', 'password')

# The path to the webdriver executable should be correct
webdriver_service = Service(ChromeDriverManager().install())

# Configure Chrome options
chrome_options = Options()
chrome_options.add_argument("--start-maximized")

# Create a new instance of the Chrome driver
driver = webdriver.Chrome(service=webdriver_service, options=chrome_options)

# Go to the Pokemon TCG login page
driver.get("https://redeem.tcg.pokemon.com")

# Wait for the page to load
time.sleep(3)

# Accept all cookies
try:
    WebDriverWait(driver, 5).until(EC.element_to_be_clickable((By.ID, "onetrust-accept-btn-handler"))).click()
except:
    pass

# Fill in the login details
driver.find_element(By.CSS_SELECTOR, 'input#email').send_keys(username)
driver.find_element(By.CSS_SELECTOR, 'input#password').send_keys(password)

# Click the login button
driver.find_element(By.CSS_SELECTOR, 'input#accept').click()

# Give it some time to login
time.sleep(5)

# Load the workbook and select the active sheet
book = load_workbook('qr_codes.xlsx')
sheet = book.active

# Read the Excel data into a pandas DataFrame
df = pd.DataFrame(sheet.values)
codes = df[0].tolist()[1:]  # Assuming codes are in the first column and skipping header

# Go to the Pokemon TCG redeem page
driver.get("https://redeem.tcg.pokemon.com")

# Wait for the page to load
time.sleep(5)

# Redeem codes
for i in range(0, len(codes), 10):
    for code in codes[i:i+10]:
        driver.find_element(By.ID, "code").send_keys(code)
        driver.find_element(By.ID, "code").send_keys(Keys.RETURN)
        time.sleep(1)  # wait a second between each code

    # Click the redeem button
    driver.find_element(By.XPATH, '//*[@id="root"]/div[2]/section/section/article/section[2]/article/div/div[3]/button[2]/span').click()
    time.sleep(2)  # wait a second for redemption to complete

    # Remove redeemed codes from the list
    codes = codes[i+10:]

    # Update the Excel file
    df = pd.DataFrame(codes, columns=['QR Code Data'])
    df.to_excel('qr_codes.xlsx', index=False)

    # Wait for the page to refresh
    time.sleep(3)  # adjust the wait period as needed

# Close the browser window
driver.quit()

# Delete the Excel file if all codes have been redeemed
if not codes:
    os.remove('qr_codes.xlsx')
